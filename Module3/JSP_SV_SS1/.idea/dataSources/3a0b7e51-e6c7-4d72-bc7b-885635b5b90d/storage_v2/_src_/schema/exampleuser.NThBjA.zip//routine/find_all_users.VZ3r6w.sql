create
    definer = root@localhost procedure find_all_users()
BEGIN
SELECT * FROM Users;
END;

