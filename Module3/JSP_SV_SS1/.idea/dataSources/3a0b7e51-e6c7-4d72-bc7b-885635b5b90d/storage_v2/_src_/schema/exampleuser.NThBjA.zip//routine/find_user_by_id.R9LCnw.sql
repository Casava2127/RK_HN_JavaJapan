create
    definer = root@localhost procedure find_user_by_id(IN user_id_in int)
BEGIN
SELECT * FROM Users WHERE user_id = user_id_in;
END;

