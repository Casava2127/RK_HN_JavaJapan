create
    definer = root@localhost procedure find_catalog_by_id(IN catalog_id_in int)
BEGIN
    SELECT * FROM Categories WHERE catalog_id = catalog_id_in;
END;

