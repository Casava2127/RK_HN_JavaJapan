create
    definer = root@localhost procedure delete_user(IN user_id_in int)
BEGIN
DELETE FROM Users WHERE user_id = user_id_in;
END;

