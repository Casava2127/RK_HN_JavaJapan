create
    definer = root@localhost procedure create_new_user(IN username_in varchar(50), IN email_in varchar(100),
                                                       IN password_in varchar(255), IN full_name_in varchar(100),
                                                       IN status_in bit)
BEGIN
INSERT INTO Users (username, email, password, full_name, status)
VALUES (username_in, email_in, password_in, full_name_in, status_in);
END;

