create
    definer = root@localhost procedure delete_catalog(IN catalog_id_in int)
BEGIN
    DELETE FROM Categories WHERE catalog_id = catalog_id_in;
END;

