create
    definer = root@localhost procedure update_catalog(IN catalog_id_in int, IN name_in varchar(255),
                                                      IN description_in text, IN status_in bit)
BEGIN
    UPDATE Categories
    SET catalog_name = name_in,
        catalog_description = description_in,
        catalog_status = status_in
    WHERE catalog_id = catalog_id_in;
END;

