create
    definer = root@localhost procedure update_user(IN user_id_in int, IN username_in varchar(50),
                                                   IN email_in varchar(100), IN password_in varchar(255),
                                                   IN full_name_in varchar(100), IN status_in bit)
BEGIN
UPDATE Users
SET username = username_in,
    email = email_in,
    password = password_in,
    full_name = full_name_in,
    status = status_in
WHERE user_id = user_id_in;
END;

