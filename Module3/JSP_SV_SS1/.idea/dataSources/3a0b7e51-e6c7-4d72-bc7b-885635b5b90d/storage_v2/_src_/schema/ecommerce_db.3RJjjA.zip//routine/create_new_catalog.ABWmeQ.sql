create
    definer = root@localhost procedure create_new_catalog(IN name_in varchar(255), IN description_in text, IN status_in bit)
BEGIN
    INSERT INTO Categories (catalog_name, catalog_description, catalog_status)
    VALUES (name_in, description_in, status_in);
END;

