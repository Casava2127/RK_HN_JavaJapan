create
    definer = root@localhost procedure find_all_categories()
BEGIN
    SELECT * FROM Categories;
END;

